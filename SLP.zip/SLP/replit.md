# SLP - Secure Line Protocol

## Project Overview

**Secure Line Protocol (SLP)** is a Python library implementing a military-grade, UDP-based application protocol with triple-layer encryption (DTLS + TLS + Noise Protocol). It includes a **Central Server Hub (CSH)** for managing services (Klar, Sverkan, Upsum) under a unified control dashboard.

## Architecture

- **`slp/`** - Core SLP protocol library (encryption, client, protocol, transport, gateway, proxy)
- **`csh/`** - Central Server Hub (service manager, config, interfaces for DCC/SLC)
- **`main.py`** - FastAPI web application serving the control dashboard on port 5000
- **`frontend/`** - Static test HTML page for protocol testing
- **`examples/`** - Usage examples for the SLP library
- **`tests/`** - pytest test suite

## Running the Application

The main workflow starts `python main.py`, which launches a FastAPI/uvicorn server on `0.0.0.0:5000`.

The dashboard provides:
- **Control Center (DCC)** - Start/Stop/Restart virtual services (Klar, Sverkan, Upsum, TestView)
- **Status Log Center (SLC)** - Real-time service health metrics and live log output
- **WebSocket** at `/ws` for live updates

## TestView Service

TestView is a verification service that demonstrates HTTPS-to-SLP protocol bridging:
- **Access**: `/testview-001/` endpoint
- **SL-ID**: testview-001
- **UDP Port**: 4274
- **Bridge Port**: 9001
- **Purpose**: Verify SLP protocol integration with HTTPS gateway translation
- **Features**: Live protocol verification, latency testing, encryption verification, payload testing

## Key Ports

- **5000** - Dashboard web UI (FastAPI/uvicorn)
- **4270** - SL Protocol base port (UDP)
- **4271** - Klar service (UDP)
- **4272** - Sverkan service (UDP)
- **4273** - Upsum service (UDP)
- **4274** - TestView service (UDP, verification/testing)
- **9001** - HTTPS-to-SLP bridge gateway (TestView)

## Dependencies

Python packages: fastapi, uvicorn, websockets, gunicorn, PyYAML, aiofiles, cryptography, pynacl, aiohttp, psutil, python-dotenv, click, colorama, python-multipart

## Deployment

Configured for autoscale deployment using:
```
gunicorn --bind=0.0.0.0:5000 --reuse-port --worker-class=uvicorn.workers.UvicornWorker main:app
```
